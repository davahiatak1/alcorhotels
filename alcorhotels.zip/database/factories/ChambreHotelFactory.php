<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\ChambreHotel;
use Faker\Generator as Faker;

$factory->define(ChambreHotel::class, function (Faker $faker) {
    return [
        //
    ];
});
