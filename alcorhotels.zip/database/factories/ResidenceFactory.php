<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\Residence;
use Faker\Generator as Faker;

$factory->define(Residence::class, function (Faker $faker) {
    return [
        //
    ];
});
