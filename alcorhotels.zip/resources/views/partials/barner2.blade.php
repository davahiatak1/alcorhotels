
  <div class="block-30 block-30-sm item" style="background-image: url('images/bg_2.jpg');" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-10">
          <span class="subheading-sm">Services</span>
              <h2 class="heading">Facilities &amp; Services</h2>
        </div>
      </div>
    </div>
  </div>
