<?php $__env->startSection('content'); ?>
 <div class="site-section">
  <div class="container">
    <div class="row mb-5">
      <div class="col-md-12">
        <img src="<?php echo e(Voyager::image($about->image)); ?>" class="img-fluid"/>
      </div>
    </div>
    <div class="row">
      <div class="col-md-1"></div>
      <div class="col-md-10"><?php echo $about->texte1; ?></div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\workspace\alcorhotels\resources\views/about.blade.php ENDPATH**/ ?>