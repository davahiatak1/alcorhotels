<?php $__env->startSection('content'); ?>
 <div class="block-30 block-30-sm item" style="background-image: url('<?php echo e(asset('images/bg_2.jpg')); ?>'); min-height: 580px;" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-10">
          <span class="subheading-sm">BLOG </span>
              <h2 class="heading">Toute l'actualité sur le<b> GROUPE ALCOR</b></h2>
        </div>
      </div>
    </div>
  </div>


 <div class=" site-section bg-light" id="blog">

    <div class="container">
      <div class="row">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12 mb-4">
          <div class="block-3 d-md-flex">
            <a class="image" href="<?php echo e(route('blog.show',$r)); ?>" style="background-image: url('<?php echo e(Voyager::image($r->image)); ?>'); "></a>
            <div class="text">
              <h2 class="heading"><a href="<?php echo e(route('blog.show',$r)); ?>"><?php echo e($r->titre); ?></a></h2>
              <p class="meta">
                <em>Posté</em> <a href="#"><?php echo e($r->created_at->diffForHumans()); ?></a>
                
                
              </p>
              <?php echo str_limit($r->texte,135); ?>

              <p><a href="<?php echo e(route('blog.show',$r)); ?>">Lire plus...</a></p>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\workspace\alcorhotels\resources\views/blog/index.blade.php ENDPATH**/ ?>