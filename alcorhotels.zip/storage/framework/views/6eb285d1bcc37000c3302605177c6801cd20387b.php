<?php $__env->startSection('content'); ?>

<div class="site-section bg-light">
    <div class="container">
        <div class="row mt-2">
            <div class="col-md-12">
                <div class="block-34">
                    <div class="image">
                        <a href="#"><img src="<?php echo e(Voyager::image($hotel->thumbnail('detail', 'image'))); ?>"></a>
                    </div>
                    <div class="text">
                        <h2 class="heading"><?php echo e($hotel->name); ?></h2>
                        
                         <?php echo $hotel->description; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>




<div class="site-section bg-light p-0">
    <div class="container">

        <div class="row mb-5 justify-content-center">
            <div class="col-md-7 text-center section-heading">
                <h2 class="heading">Les salles et chambres de <?php echo e($hotel->name); ?></h2>
                <p>Cliquez vous voir plus de description sur une chambre ou la salle de <?php echo e($hotel->name); ?></p>
            </div>
        </div>

        <div class="row">
            <?php $__currentLoopData = $chambres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chambre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 mb-5">
                    <div class="block-34">
                        <div class="image">
                            <a href="<?php echo e(route('chambres.show', ['hotel' => $hotel, 'chambre' => $chambre])); ?>"><img src="<?php echo e(Voyager::image($chambre->thumbnail('cropped', 'image'))); ?>" alt="<?php echo e($chambre->name); ?>"></a>
                        </div>
                        <div class="text">
                            <h2 class="heading"><?php echo e(str_limit($chambre->name, 90)); ?></h2>
                            
                            <div class="price"><span class="number"><?php echo e($chambre->prix); ?> </span><sub>FCFA/par jour</sub></div>

                            <ul class="specs">
                                <li><strong>Adults:</strong> <?php echo e($chambre->adulte); ?></li>
                                <li><strong>Categories:</strong> <?php echo e($chambre->categorie); ?></li>
                                <li><strong>Facilities:</strong> 
                                    <?php
                                        $facilitie = str_replace_array('"', [' ',], $chambre->facilitie);

                                        $facilitie = str_replace_array('[', [' ',], $facilitie);

                                        $facilitie = str_replace_array('"]', [' ',], $facilitie);

                                        $facilitie = str_replace_array('","', [', ',], $facilitie);
                                    ?>
                                    <?php echo e($facilitie); ?></li>
                                <li><strong>Size:</strong> <?php echo e($chambre->size); ?>m<sup>2</sup></li>
                                <li><strong>Bed Type:</strong> <?php echo e($chambre->bed); ?> bed</li>
                            </ul>
                            
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\workspace\alcorhotels\resources\views/hotels/show.blade.php ENDPATH**/ ?>