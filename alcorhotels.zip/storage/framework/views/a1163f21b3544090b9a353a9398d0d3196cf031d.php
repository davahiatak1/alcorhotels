<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($name); ?> a besoin de votre service

## Demande ou message : <?php echo e($message); ?> 

## E-mail du client :  <?php echo e($email); ?>


## Numero du client : <?php echo e($phone); ?>




<?php $__env->startComponent('mail::button', ['url' => 'http://alcorhotels.info/admin']); ?>
Accéder au site
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\workspace\alcorhotels\resources\views/emails/contact-and-reserve.blade.php ENDPATH**/ ?>