<?php echo e($slot); ?>

<?php /**PATH C:\workspace\alcorhotels\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>