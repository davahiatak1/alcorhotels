<?php $__env->startSection('content'); ?>
 <div class="block-30 block-30-sm item" style="background-image: url('<?php echo e(asset('images/bg_2.jpg')); ?>'); min-height: 580px;" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-10">
          <span class="subheading-sm">BLOG </span>
              <h2 class="heading">Toute l'actualité sur le<b> GROUPE ALCOR</b></h2>
        </div>
      </div>
    </div>
  </div>


  <div id="blog" class="site-section">
    <div class="container">

      <div class="row">

        <div class="col-md-8">
          <h2 class="mb-3"><?php echo e($post->titre); ?></h2>
          <p><img src="<?php echo e(Voyager::image($post->thumbnail('cropped', 'image'))); ?>" alt="" class="img-fluid"></p>
          <?php echo $post->texte; ?>

        </div>

        <div class="col-md-4 sidebar">

          <div class="sidebar-box">
            <div class="categories">
              <h3>Articles</h3>
              <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(route('blog.show',$r)); ?>"><?php echo e($r->titre); ?> </a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\workspace\alcorhotels\resources\views/blog/show.blade.php ENDPATH**/ ?>