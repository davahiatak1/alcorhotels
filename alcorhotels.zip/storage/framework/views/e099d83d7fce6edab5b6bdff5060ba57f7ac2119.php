<?php $__env->startSection('content'); ?>
 <div class="block-30 block-30-sm item" style="background-image: url('<?php echo e(asset('images/bg_2.jpg')); ?>'); min-height: 580px;" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-10">
          <span class="subheading-sm">Appartements </span>
              <h2 class="heading">Des appartements luxueux</h2>
        </div>
      </div>
    </div>
  </div>

<div class="site-section bg-light">
	<div class="container">
		<div class="row mb-5">

			<?php $__currentLoopData = $appartements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appartement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($loop->iteration%2): ?>
					<div class="col-md-12 mb-5">

						<div class="block-3 d-md-flex">
							<div class="image" style="background-image: url('<?php echo e(Voyager::image($appartement->thumbnail('cropped', 'image'))); ?>'); "></div>
							<div class="text">

								<h2 class="heading"><?php echo e(str_limit($appartement->name, 90)); ?></h2>

								<div class="price"><span class="number"><?php echo e($appartement->prix); ?> </span><sup>FCFA/par semaine</sup></div>

								<?php echo str_limit($appartement->description, 255); ?>


								<p><a href="<?php echo e(route("appartements.show", $appartement)); ?>" class="btn btn-primary py-3 px-5">Voir Plus</a></p>

							</div>
						</div>


					</div>

				<?php else: ?>
					<div class="col-md-12 mb-5">

						<div class="block-3 d-md-flex">
							<div class="image order-2" style="background-image: url('<?php echo e(Voyager::image($appartement->thumbnail('cropped', 'image'))); ?>'); "></div>
							<div class="text order-1">

								<h2 class="heading"><?php echo e(str_limit($appartement->name, 90)); ?></h2>

								<?php echo str_limit($appartement->description, 255); ?>


								<p><a href="<?php echo e(route("appartements.show", $appartement)); ?>" class="btn btn-primary py-3 px-5">Voir Plus</a></p>

							</div>
						</div>


					</div>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


		</div>
	</div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\workspace\alcorhotels\resources\views/appartements/index.blade.php ENDPATH**/ ?>