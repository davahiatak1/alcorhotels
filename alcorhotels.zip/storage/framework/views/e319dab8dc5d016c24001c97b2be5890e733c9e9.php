<?php $__env->startSection('content'); ?>

  <div class="block-30 block-30-sm item" style="background-image: url('images/bg_3.jpg'); min-height: 580px;" data-stellar-background-ratio="0.5">
    <div class="container">
      <div class="row align-items-center">
        <div class="col-md-10">
          <span class="subheading-sm">Restauration</span>
              <h2 class="heading">Nos Restaurants et leur meilleurs Plats</h2>
        </div>
      </div>
    </div>
  </div>

  <div class="container">
    <div class=" site-section">
     <?php $__currentLoopData = $restaurants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="row ">
      
      <div class="col-lg-7 mb-5">
        <img src="<?php echo e(Voyager::image($r->image)); ?>" class="img-fluid img-shadow"/>
        
      </div>
      <div class="col-lg-5 pl-md-5">

        <div class="media block-6">
          <div class="icon"><span class="ion-ios-checkmark"></span></div>
          <div class="media-body">
            <h3 class="heading"><?php echo e($r->nom); ?></h3>
            <p><?php echo $r->description; ?></p>
            <a href="<?php echo e(route('restaurant.show',$r->id)); ?>" class="btn btn-primary">Détails</a>
          </div>

        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-2"></div>
      <div  class="col-lg-8" style="border: 1px solid gray;"></div>
      <div class="col-lg-2"></div>
    </div>
    <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\workspace\alcorhotels\resources\views/restaurant/index.blade.php ENDPATH**/ ?>